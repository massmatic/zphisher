<?php
include 'ip.php';
header('Location: users.php');
exit
?>
